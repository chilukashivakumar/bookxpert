import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import './Grid.css' ;
import VideocamOutlinedIcon from '@mui/icons-material/VideocamOutlined';
import AccessAlarmIcon from '@mui/icons-material/AccessAlarm';
import ThreeDRotation from '@mui/icons-material/ThreeDRotation';
import PlayCircleOutlineIcon from '@mui/icons-material/PlayCircleOutline';
import OutlinedCard from './card'
import MailOutlineIcon from '@mui/icons-material/MailOutline';
import GridViewIcon from '@mui/icons-material/GridView';



const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function BasicGridlist() {
  return (
    <div className='mar-top Developer-Community'>
    
  
    <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>

        <Grid   item xs={12} md={8}>
        
          <Item>
          <h3> <VideocamOutlinedIcon></VideocamOutlinedIcon> Developer Community</h3>
           <div className='Understand'>  <PlayCircleOutlineIcon></PlayCircleOutlineIcon></div>
         
            
          </Item>
        </Grid>
        <Grid item xs={12} md={4}>
        <Grid item xs={12}>
          <Item>
          <h3> <MailOutlineIcon></MailOutlineIcon> In the news</h3>
          <div className='icon-1'>
        <h4 className='icon-2022'> ICON 2022</h4>
        <p className='Florida'> Florida, FL & Virtual - May 23-25</p>
        <span className='date'> May 23, 2022</span>
        </div>
        <div className='icon-1'>
        <h4 className='icon-2022'> Security Advisory</h4>
        <p className='Florida'> Urgent Security Advisory (CVE-2022-22965) - Update 1</p>
        <span className='date'> April 1, 2022</span>
        </div>
        </Item>
        </Grid>
        <Grid item xs={12}>
          <Item>
          <h3> <GridViewIcon></GridViewIcon> Products</h3>
          <h4 className='icon-2022'>Latest Releases</h4>
          <a href='#' className='Workforce'>Workforce Management 2022.1.0.0</a>
          <span className='date'> July 20, 2022</span>
          <p className='Florida mar-bottom-10'>This release further enhances our support
             of predictive scheduling legislation which benefits employees
              with key aspects like the ability to dispute edits to their
               posted schedules within defined thresholds. </p>
               <Stack spacing={2} direction="row">
            <Button variant="outlined"> Older Releases</Button>
            <Button variant="outlined">All Products</Button>
    </Stack>
          </Item>
        </Grid>
        </Grid>
  
       
        
      </Grid>
    </Box>
    </div>
   
  );
}
