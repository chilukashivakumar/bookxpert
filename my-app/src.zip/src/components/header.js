import * as React from 'react';
import './herder.css'
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';




export default function Headerpage() {
  return (
    <div className='welcome-user'>
      <div className='container'>
      <h2>Welcome Dinesh</h2>
      <div className='Sandbox'>
      <Stack spacing={2} direction="row">
    
      <Button variant="contained">Go To Sandbox Realm</Button>
     
    </Stack>
      </div>
      </div>
    </div>
  );
}
