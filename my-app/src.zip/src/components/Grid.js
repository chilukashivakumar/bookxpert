import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import './Grid.css' ;




const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function BasicGrid() {
  return (
    <div className='What-do'>
      <h3>  What do you want to do today?</h3>
  
    <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
        <Grid item xs={12} md={4}>
          <Item>
           <div className='Understand'></div>
            <p className='text-left'>Understand how our data is modeled and how to map to it</p>
            <Stack spacing={2} direction="row">
            <Button variant="outlined">Learn More</Button>
    </Stack>
          </Item>
        </Grid>
        <Grid item xs={12} md={4}>
          <Item>
          <div className='Understand'></div>
          <p className='text-left'>Understand how our data is modeled and how to map to it</p>
            <Stack spacing={2} direction="row">
            <Button variant="outlined">Learn More</Button>
    </Stack></Item>
        </Grid>
        <Grid item xs={12} md={4}>
          <Item>
            <div className='Understand'></div>
          <p className='text-left'>Understand how our data is modeled and how to map to it</p>
            <Stack spacing={2} direction="row">
            <Button variant="outlined">Learn More</Button>
    </Stack></Item>
        </Grid>
        
      </Grid>
    </Box>
    </div>
   
  );
}
