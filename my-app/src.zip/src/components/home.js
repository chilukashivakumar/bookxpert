import React from 'react';
import BasicButtons from './button';

import BasicGrid from './Grid';
import ListDividers from './ListDividers';
import Headerpage from './header';
import BasicGridlist from './Grid2'
 
export default function HomePage() {
    return (
        <div>
      
        <Headerpage></Headerpage>
     <div className='container'>
     <BasicGrid>
        </BasicGrid>
<BasicGridlist></BasicGridlist>
   
        <BasicButtons>
        </BasicButtons>
    
      
        <ListDividers>
        </ListDividers>
      
     </div>
     </div>
    );
}